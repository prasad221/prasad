package com.infysim.exceptions;

public class SimNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	public SimNotFoundException(String message) {
		super(message);
	}
	
}
