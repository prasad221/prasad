package com.infysim;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimCardActivationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimCardActivationApplication.class, args);
	}

}
