package com.infySim;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimCardActivationApplicationTests {

	@Test
	void contextLoads() {
	}

}
